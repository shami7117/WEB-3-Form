export default function HandlesList() {
    return (
        <div className="my-handles">
            <h2>My Handles</h2>
            <ul id="my-handles-list">
                {/* Handles will be listed here */}
            </ul>
        </div>
    );
}
