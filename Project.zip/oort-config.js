export const oortConfig = {
    agentId: "g5QCbOZt_rPjykhxpLk1f",
    secretKey: "K4nWPOqH_Ec76Gg16u5Eo",
};
